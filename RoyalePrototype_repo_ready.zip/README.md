# RoyalePrototype (Android/Kotlin) — Repo listo

Prototipo estilo *Clash Royale* con 2 carriles, 3 torres por lado, 4 cartas y maná.
Incluye **GitHub Actions** para compilar el APK en la nube.

## Estructura
- `settings.gradle`, `build.gradle.kts`
- `app/` (código)
- `.github/workflows/android.yml` (CI)

## Cómo obtener el APK (sin PC)
1. Subí TODO este repo tal cual a GitHub.
2. Abrí la pestaña **Actions** → workflow **Android APK (Cloud Build)** → **Run workflow**.
3. Al terminar verde, descargá el artifact `royale-debug-apk` → `app-debug.apk`.

## Local (Android Studio)
Build → Build APK(s) → `app/build/outputs/apk/debug/app-debug.apk`
