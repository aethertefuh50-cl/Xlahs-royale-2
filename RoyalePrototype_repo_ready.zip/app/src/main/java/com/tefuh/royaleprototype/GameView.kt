package com.tefuh.royaleprototype

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.SurfaceHolder
import android.view.SurfaceView
import kotlin.math.max
import kotlin.math.min

enum class Team { PLAYER, ENEMY }
enum class UnitType { KNIGHT, ARCHER, GIANT, MAGE }

data class Tower(var x: Float, var y: Float, var w: Float, var h: Float, var hp: Float, val team: Team) {
    fun rect() = RectF(x - w/2f, y - h/2f, x + w/2f, y + h/2f)
}
data class UnitEntity(
    var x: Float, var y: Float, var w: Float, var h: Float, var hp: Float,
    var speed: Float, var damage: Float, var range: Float, var attackCd: Float,
    var team: Team, var type: UnitType, var lane: Int, var cdTimer: Float = 0f
) { fun rect() = RectF(x - w/2f, y - h/2f, x + w/2f, y + h/2f) }

class ManaSystem {
    var current = 5f
    private val maxMana = 10f
    private val regenPerSecond = 1f
    fun update(dt: Float) { current = min(maxMana, current + regenPerSecond * dt) }
    fun canSpend(cost: Int) = current >= cost
    fun spend(cost: Int): Boolean { if (current >= cost) { current -= cost; return true } ; return false }
}

class GameView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) :
    SurfaceView(context, attrs), SurfaceHolder.Callback, Runnable {

    private var gameThread: Thread? = null
    @Volatile private var running = false

    private var widthF = 1f
    private var heightF = 1f
    private val laneY = FloatArray(2) { 0f }
    private val units = mutableListOf<UnitEntity>()
    private val towers = mutableListOf<Tower>()
    private val mana = ManaSystem()
    private var timeLeft = 3 * 60f

    private val spawnQueue = mutableListOf<Pair<UnitType, Team>>()

    private val bgPaintTop = Paint().apply { color = Color.rgb(120, 190, 255) }
    private val bgPaintBottom = Paint().apply { color = Color.rgb(100, 180, 100) }
    private val riverPaint = Paint().apply { color = Color.rgb(60,130,200) }
    private val linePaint = Paint().apply { color = Color.WHITE; strokeWidth = 3f; style = Paint.Style.STROKE }
    private val textPaint = Paint().apply { color = Color.WHITE; textSize = 36f; isAntiAlias = true }
    private val playerPaint = Paint().apply { color = Color.rgb(70,130,255) }
    private val enemyPaint = Paint().apply { color = Color.rgb(255,90,90) }
    private val towerPaintP = Paint().apply { color = Color.rgb(40,90,200) }
    private val towerPaintE = Paint().apply { color = Color.rgb(200,60,60) }
    private val hpPaint = Paint().apply { color = Color.GREEN }

    init { holder.addCallback(this) }

    fun queueSpawn(type: UnitType, team: Team) { synchronized(spawnQueue) { spawnQueue.add(type to team) } }

    override fun surfaceCreated(holder: SurfaceHolder) { running = true; gameThread = Thread(this, "GameThread"); gameThread?.start() }
    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        widthF = width.toFloat(); heightF = height.toFloat()
        laneY[0] = heightF * 0.35f; laneY[1] = heightF * 0.65f
        setupWorld()
    }
    override fun surfaceDestroyed(holder: SurfaceHolder) { running = false; gameThread?.join() }

    fun resume() { if (!running) { running = true; gameThread = Thread(this, "GameThread"); gameThread?.start() } }
    fun pause() { running = false; gameThread?.join() }

    private fun setupWorld() {
        units.clear(); towers.clear()
        val tw = 60f; val th = 80f; val margin = 80f
        towers.add(Tower(margin, laneY[0] + 40f, tw, th, 800f, Team.PLAYER))
        towers.add(Tower(margin, laneY[1] - 40f, tw, th, 800f, Team.PLAYER))
        towers.add(Tower(widthF * 0.15f, heightF * 0.5f, tw + 10, th + 10, 1200f, Team.PLAYER))

        towers.add(Tower(widthF - margin, laneY[0] + 40f, tw, th, 800f, Team.ENEMY))
        towers.add(Tower(widthF - margin, laneY[1] - 40f, tw, th, 800f, Team.ENEMY))
        towers.add(Tower(widthF * 0.85f, heightF * 0.5f, tw + 10, th + 10, 1200f, Team.ENEMY))

        mana.current = 5f; timeLeft = 3 * 60f
    }

    override fun run() {
        var last = System.nanoTime(); val nsPerSec = 1_000_000_000.0
        while (running) {
            val now = System.nanoTime(); val dt = ((now - last) / nsPerSec).toFloat(); last = now
            update(dt); drawFrame()
        }
    }

    private fun update(dt: Float) {
        synchronized(spawnQueue) { for ((type, team) in spawnQueue) trySpawn(type, team); spawnQueue.clear() }

        aiTimer -= dt
        if (aiTimer <= 0f) { aiTimer = 2.5f; trySpawn(UnitType.values().random(), Team.ENEMY) }

        for (u in units) {
            u.cdTimer = max(0f, u.cdTimer - dt)
            val enemies = units.filter { it.team != u.team } +
                towers.filter { it.team != u.team }.map {
                    UnitEntity(it.x, it.y, it.w, it.h, it.hp, 0f, 0f, 0f, 0f, if (u.team==Team.PLAYER) Team.ENEMY else Team.PLAYER, UnitType.KNIGHT, u.lane)
                }
            val target = enemies.minByOrNull { dist2(u.x, u.y, it.x, it.y) }
            if (target != null) {
                val d2 = dist2(u.x, u.y, target.x, target.y)
                if (d2 <= (u.range * u.range)) {
                    if (u.cdTimer <= 0f) { u.cdTimer = u.attackCd; applyDamage(target, u.damage) }
                } else {
                    val dir = if (u.team == Team.PLAYER) 1f else -1f
                    u.x += u.speed * dir * dt
                }
            }
        }
        units.removeAll { it.hp <= 0f }
        for (t in towers) if (t.hp < 0f) t.hp = 0f
        mana.update(dt)
        timeLeft = max(0f, timeLeft - dt)
    }

    private fun applyDamage(target: UnitEntity, dmg: Float) {
        val fakeRect = RectF(target.x-1, target.y-1, target.x+1, target.y+1)
        val tower = towers.find { fakeRect.contains(it.x, it.y) }
        if (tower != null) tower.hp -= dmg else target.hp -= dmg
    }

    private var aiTimer = 1.5f

    private fun trySpawn(type: UnitType, team: Team) {
        val (cost, stats) = when(type) {
            UnitType.KNIGHT -> 3 to Stats(220f, 90f, 35f, 30f, 0.8f, 36f, 36f)
            UnitType.ARCHER -> 2 to Stats(120f, 95f, 18f, 140f, 0.6f, 28f, 28f)
            UnitType.GIANT  -> 5 to Stats(520f, 60f, 55f, 28f, 1.0f, 42f, 42f)
            UnitType.MAGE   -> 4 to Stats(150f, 80f, 28f, 120f, 0.5f, 30f, 30f)
        }
        if (team == Team.PLAYER) { if (!mana.canSpend(cost)) return; mana.spend(cost) }
        val lane = (0..1).random()
        val x = if (team == Team.PLAYER) widthF * 0.25f else widthF * 0.75f
        val y = laneY[lane] + (if (lane==0) -20f else 20f)
        units.add(UnitEntity(x, y, stats.w, stats.h, stats.hp, stats.speed, stats.dmg, stats.range, stats.cd, team, type, lane))
    }

    data class Stats(val hp:Float, val speed:Float, val dmg:Float, val range:Float, val cd:Float, val w:Float, val h:Float)

    private fun dist2(x1:Float,y1:Float,x2:Float,y2:Float):Float { val dx=x2-x1; val dy=y2-y1; return dx*dx+dy*dy }

    private fun drawFrame() {
        val c = holder.lockCanvas() ?: return
        try {
            c.drawRect(0f, 0f, widthF, heightF*0.5f, bgPaintTop)
            c.drawRect(0f, heightF*0.5f, widthF, heightF, bgPaintBottom)
            c.drawRect(widthF*0.48f, 0f, widthF*0.52f, heightF, riverPaint)
            for (y in laneY) c.drawLine(0f, y, widthF, y, linePaint)

            for (t in towers) {
                val p = if (t.team==Team.PLAYER) towerPaintP else towerPaintE
                c.drawRoundRect(t.rect(), 12f, 12f, p)
                val maxHp = if (t.h>80) 1200f else 800f
                val hpW = 60f * (t.hp / maxHp).coerceIn(0f,1f)
                val bar = RectF(t.x-30, t.y - t.h/2f - 12f, t.x-30 + hpW, t.y - t.h/2f - 6f)
                c.drawRect(bar, hpPaint)
            }
            for (u in units) {
                val p = if (u.team==Team.PLAYER) playerPaint else enemyPaint
                c.drawRoundRect(u.rect(), 8f, 8f, p)
                val base = when (u.type) { UnitType.KNIGHT->220f; UnitType.ARCHER->120f; UnitType.GIANT->520f; UnitType.MAGE->150f }
                val hpW = u.w * (u.hp / base).coerceIn(0f,1f)
                val bar = RectF(u.x - u.w/2f, u.y - u.h/2f - 6f, u.x - u.w/2f + hpW, u.y - u.h/2f - 2f)
                c.drawRect(bar, hpPaint)
            }
            val manaText = "Mana: " + String.format("%.1f/10", mana.current)
            val timeText = "Tiempo: " + formatTime(timeLeft)
            c.drawText("$manaText   $timeText", 16f, 48f, textPaint)
        } finally { holder.unlockCanvasAndPost(c) }
    }

    private fun formatTime(s: Float): String { val m = (s.toInt())/60; val sec=(s.toInt())%60; return "%d:%02d".format(m, sec) }
}
