package com.tefuh.royaleprototype

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.tefuh.royaleprototype.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnKnight.setOnClickListener { binding.gameView.queueSpawn(UnitType.KNIGHT, Team.PLAYER) }
        binding.btnArcher.setOnClickListener { binding.gameView.queueSpawn(UnitType.ARCHER, Team.PLAYER) }
        binding.btnGiant.setOnClickListener { binding.gameView.queueSpawn(UnitType.GIANT, Team.PLAYER) }
        binding.btnMage.setOnClickListener { binding.gameView.queueSpawn(UnitType.MAGE, Team.PLAYER) }
    }
    override fun onResume() { super.onResume(); binding.gameView.resume() }
    override fun onPause() { super.onPause(); binding.gameView.pause() }
}
